# Evalution Results on LTAFDB of the RR_LSTM model trained on CPSC2021 data

Files are stored in the `.mat` format, with fields:
- rpeak_indices: indices of the R peaks
- af_itvs: intervals of annotated AF events, in the form of [[a1, b1], [a2, b2], ...]
- pred_itvs: intervals of the predicted AF events, in the same form as `af_itvs`
- fs: the sampling frequency

One can use the following function to convert the intervals to beat-wise labels (predictions)
```python
def itvs_to_cls(rpeaks, itvs):
    mask = np.zeros(rpeaks[-1] + 100)
    for itv in itvs:
        mask[itv[0]:itv[1]] = 1
    ret = mask[np.array(rpeaks)]
    return ret
```

To compute the metrics, one can use the following code:
```python
from pathlib import Path
import scipy.io as sio
from torch_ecg.components.metrics import ClassificationMetrics
labels = {}
preds = {}
for file in Path("/path/to/the/folder/").rglob("*.mat"):
    d = sio.loadmat(file)
    labels[file.name.replace("_rr_lstm.mat", "")] = itvs_to_cls(d["rpeak_indices"].flatten(), d["af_itvs"])
    preds[file.name.replace("_rr_lstm.mat", "")] = itvs_to_cls(d["rpeak_indices"].flatten(), d["pred_itvs"])

cm = ClassificationMetrics()
all_metrics = cm(np.concatenate(list(labels.values()), 0), np.concatenate(list(preds.values()), 0), 2)
```
